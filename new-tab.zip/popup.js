

chrome.runtime.onMessage.addListener(function (request) { 
  if (request.urlProtocol) {
      let container = document.getElementById('content');
      if (! container) {
          container = document.createElement('div');
          container.id = 'content';
          document.body.appendChild(container);
      }
      container.innerHTML = '';

      if (request.urlProtocol === 'https:') {
          container.innerHTML = `
          <nav class="navbar-safe navbar">
              <img src="icons/navLogo.png" alt="Logo">
      </nav>
      <div class="pt-3 pb-2">
                 <div class="text-center mt-1 d-flex align-items-center justify-content-center">
                   <img src="icons/safe.png" alt="Center Image" class="img-fluid pb-1 mr-2">
                   <h2 class="">Safe</h2>
                 </div>
                 <div class="my-2 ">
                   <p class="text-center para">This website is safe to proceed</p>
                 </div>
                 </div>
        `;
      } else if (request.urlProtocol === 'http:') {

          container.innerHTML = `
          <nav class="navbar">
              <img src="icons/navLogo.png" alt="Logo">
      </nav>
      <div class="pt-3 pb-2">
               <div class="text-center mt-1 d-flex align-items-center justify-content-center">
                   <img src="icons/warning1.png" alt="Center Image" class="img-fluid mr-2">
                   <h2 class="mt-2 ">Warning</h2>
                 </div>
                 <div class="mt-1 para">
                   <p class="text-center">This website has a risk factor and seems to be malicious</p>
                 </div>
                 </div>
        `;
      }
  }
});
document.addEventListener("DOMContentLoaded", function() {

  chrome.runtime.sendMessage({ message: "Hello from the popup!", action:"from-popup" });

});


