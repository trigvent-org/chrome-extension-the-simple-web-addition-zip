6// content.js
console.log("Content.js called");

// Function to send the current search query to the background script
function SearchQuery() {
  const completeUrl = new URL(window.location.href);
  const searchQuery = completeUrl.searchParams.get("q") || "No search query found";
  console.log('Complete URL:', completeUrl);
  console.log('Current Protocol:', completeUrl.protocol);
  console.log('Search Query:', searchQuery);
      
      var httpStatusCode;
      const currentUrl = window.location.href;
      
      // Fetch the URL to check the HTTP status code
      fetch(currentUrl, { method: 'HEAD' }) 
      .then(response => {
        httpStatusCode = response.status;
        console.log('Content Script: HTTP Status Code:', response.status);

        if(completeUrl.origin === "https://www.figma.com"){
          chrome.runtime.sendMessage({ completeUrl: completeUrl.href, urlProtocol: completeUrl.protocol, statusCode: "200"});
          
        }else{
          // Send message to background.js
          chrome.runtime.sendMessage({ completeUrl: completeUrl.href, urlProtocol: completeUrl.protocol, statusCode: httpStatusCode});
        }
      })
      .catch(error => {
        console.error('Content Script: Fetch Error:', error.message);
      });
      
}
// Execute the function when the page has loaded
window.onload = SearchQuery;
// Access the device token from chrome.storage
chrome.storage.local.get(['device_token'], function(result) {
  const deviceToken = result.device_token;
  console.log('Device Token in content.js:', deviceToken);

});