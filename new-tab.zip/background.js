console.log("Background.js called");
chrome.storage.local.set({ visitedSites: [] });
var completeUrl;
var urlProtocol;
var httpStatusCode;
var responseStatus;
const manifest = chrome.runtime.getManifest();
const deviceToken = manifest.storage.device_token;
console.log('device_token:', deviceToken);
chrome.storage.local.set({ 'device_token': deviceToken });
const crossIconPath = 'icons/cross.png';
const safeIconPath = 'icons/Shield.png';
const defaultLogoPath='icons/sww.png'


// Function to update the extension icon
function updateExtensionIcon(iconPath) {
  chrome.action.setIcon({ path: iconPath });
}

chrome.runtime.onMessage.addListener(
  async function (request) {
    // Log the received values
    console.log('Received Complete URL:', request.completeUrl);
    console.log('Received Complete URL:', request.urlProtocol);
    console.log('Received Complete URL:', request.statusCode);
    if(request.action=="from-popup"){
      chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
        
        chrome.runtime.sendMessage({urlProtocol:tabs[0].url.split('\/\/')[0]});
      })
    }

    if (completeUrl === request.completeUrl) {
        const isMonitored = await isSiteMonitored(deviceToken);

        if (isMonitored==1) {
          console.log("On the Same Page, But site monitored is on.")
        }else if(isMonitored==0){
          console.log("On the Same Page.");
          return;
        }
    }

    if (await checkStoredUrl(request.completeUrl)) {
      console.log("Url already Saved.");
      return;
    } else {
      console.log("Else Part run.");
      completeUrl = request.completeUrl;
      urlProtocol = request.urlProtocol;
      httpStatusCode = request.statusCode;
      // You can perform further actions with the received values here
      console.log(completeUrl, urlProtocol, httpStatusCode);
      if (httpStatusCode === 404) {
        responseStatus = 4;
        console.log('It is not a valid URL or IP address.', responseStatus);
      } else if (isIpAddress(request.completeUrl)) {
        responseStatus = 3;
        console.log('It is an IP address.', responseStatus);
        // updateExtensionIcon(crossIconPath);
      } else if (urlProtocol === 'http:') {
        responseStatus = 2;
        console.log('Url is not secure.', responseStatus);
        updateExtensionIcon(crossIconPath);
      } else {
        responseStatus = 1;
        console.log('Url is secure.', responseStatus);
        
      }
      console.log("deviceToken",deviceToken)
      const isMonitored = await isSiteMonitored(deviceToken);

          if (isMonitored==1) {
          saveUrlToLocalStorage(completeUrl, responseStatus);
        } 
    
      // saveVisitedUrls(completeUrl, responseStatus);
    }
return true;
  }
); 
// Function to check if a string is a valid IP address
function isIpAddress(input) {
  // Regular expression for matching an IP address
  const ipRegex = /^(?:[0-9]{1,3}\.){3}[0-9]{1,3}$/;
  return ipRegex.test(input);
}

function saveVisitedUrls() {
  console.log("saveVisitedUrls Called");
  chrome.storage.local.get({ visitedSites: [] }, function (result) {
    // Update the array with new data
    var visitedSites = result.visitedSites;

    if (visitedSites && visitedSites.length > 0) {
      console.log("Visited Sites Data:", visitedSites);
      var myHeaders = new Headers();
      myHeaders.append("Content-Type", "application/json");

      var raw = JSON.stringify({
        "device_token": deviceToken,
        "url_data": visitedSites
      });

      var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: raw,
        redirect: 'follow'
      };

      fetch("https://thesimplewebaddition.com/wp-json/api/v1/save_visited_url", requestOptions)
        .then(response => response.text())
        .then(result => console.log(result))
        .catch(error => console.log('error', error));


      // Clear the local storage
      clearVisitedSitesData();
    } else {
      console.log("Visited Sites Data is empty.");
    }
  });
}

function clearVisitedSitesData() {
  chrome.storage.local.remove('visitedSites', function() {
    console.log("Visited sites data cleared.");
  });
}
function saveUrlToLocalStorage(completeUrl, responseStatus) {

  if (completeUrl.trim() === "") {
    console.log("Empty URL. Not saving.");
    return;
  }
  var siteData = {
    url: completeUrl,
    status: responseStatus
  };

  // Retrieve existing data from storage
  chrome.storage.local.get({ visitedSites: [] }, function (result) {
    // Update the array with new data
    var visitedSites = result.visitedSites;
    visitedSites.push(siteData);

    // Save the updated array back to storage
    chrome.storage.local.set({ visitedSites: visitedSites });
  });
}
// Function to check if a URL is saved
async function checkStoredUrl(urlToCheck) {
  return new Promise(resolve => {
    chrome.storage.local.get({ visitedSites: [] }, function (result) {
      // Update the array with new data
      var visitedSites = result.visitedSites;

      var isUrlSaved = visitedSites.some(function (site) {
        return site.url === urlToCheck;
      });

      resolve(isUrlSaved);
    });
  });
}
chrome.alarms.create({ periodInMinutes: 0.25 });

chrome.alarms.onAlarm.addListener(() => {
  console.log("Alarm hit..");
  saveVisitedUrls();
  isSiteMonitored();
});


chrome.runtime.onInstalled.addListener(function () {
  chrome.tabs.onActivated.addListener(updatePopup);
  chrome.tabs.onUpdated.addListener(updatePopup);
});

function updatePopup() {
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
 
    if (tabs && tabs.length > 0 && tabs[0].url && !tabs[0].url.startsWith('chrome://extensions') && !tabs[0].url.startsWith('chrome://newtab')) {
      chrome.action.setPopup({ popup: "popup.html" });
    } else {
      chrome.action.setPopup({ popup: "" });
    }
  });
}


function updateIconOnPageChange(tabId) {
  chrome.tabs.get(tabId, function (tab) {
    if (tab && tab.url ) {
      const urlProtocol = new URL(tab.url).protocol;

      if (urlProtocol === 'http:') {
        updateExtensionIcon(crossIconPath);
      } else if (urlProtocol === 'https:') {
        updateExtensionIcon(safeIconPath);
      } else if(tab.url.startsWith('chrome://extensions') || tab.url.startsWith('chrome://newtab')) {
        console.log("object")

        updateExtensionIcon(defaultLogoPath);
       
      }
    }
  });
}

chrome.tabs.onActivated.addListener(function (activeInfo) {
  updateIconOnPageChange(activeInfo.tabId);
});

chrome.tabs.onUpdated.addListener(function (tabId, changeInfo, tab) {
  if (changeInfo.url) {
    updateIconOnPageChange(tabId);
  }
});

async function isSiteMonitored(deviceToken) {
  const apiUrl = `https://thesimplewebaddition.com/wp-json/api/v1/get_device_settings?device_token=${deviceToken}`;

  console.log(apiUrl)

  try {
    const response = await fetch(apiUrl);
    if (!response.ok) {
      throw new Error(`Failed to fetch data. Status: ${response.status}`);
    }

    const data = await response.json();

    return data.data.site_monitored == 1;
  } catch (error) {
    console.error('Error:', error.message);
    return false; 
  }
}
